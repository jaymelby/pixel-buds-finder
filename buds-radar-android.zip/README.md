# Buds Radar (Pixel Buds Pro 2 BLE `0xFE2C` Locator)

Zero-dependency Android Kotlin + Jetpack Compose proximity and body-shielding polar radar app for locating a Google Fast Pair (`0xFE2C`) earbud charging case.

## Fastest Phone-Only Build (GitHub Actions — ~2.5 Minutes)
Because Android's mobile file picker strips nested folder paths when uploading to GitHub, `.github/workflows/build.yml` automatically detects and unpacks `buds-radar-android.zip` on the runner if uploaded directly:

1. Create a new **Private** repository at `https://github.com/new` (check **Add a README file**).
2. In mobile Chrome, open the `⋮` menu and check **Desktop site** so GitHub shows the **Add file** dropdown.
3. Tap **Add file -> Upload files**, select `buds-radar-android.zip` directly (no need to unzip on your phone), and commit.
4. Tap **Add file -> Create new file**, name it `.github/workflows/build.yml`, paste the workflow YAML from `.github/workflows/build.yml`, and commit.
5. Open the **Actions** tab, wait ~2 minutes for **Build Buds Radar APK** to turn green, scroll to **Artifacts**, download `buds-radar-debug-apk`, and tap `app-debug.apk` inside **Files by Google** to install.

## Desktop / CLI Git Push
If pushing from a terminal or opening in Android Studio, simply unzip `buds-radar-android.zip` normally:
```bash
unzip buds-radar-android.zip -d buds-radar
cd buds-radar
```
