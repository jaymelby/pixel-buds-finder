package com.local.budsradar

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class RssiKalmanFilter(
    var processNoisePerSec: Double = 1.4, // Q: dB^2 / sec (higher = tracks walking faster)
    var measurementNoise: Double = 14.0   // R: dB^2 (indoor BLE multipath variance)
) {
    private var initialized = false
    private var estimate = -80.0
    private var errorCov = 25.0
    private var lastUpdateMs = 0L

    val currentDbm: Double get() = estimate
    val isInitialized: Boolean get() = initialized

    fun update(rawRssi: Int, nowMs: Long): Double {
        val z = rawRssi.toDouble()
        if (!initialized) {
            initialized = true
            estimate = z
            errorCov = measurementNoise
            lastUpdateMs = nowMs
            return estimate
        }

        val dtSec = ((nowMs - lastUpdateMs).coerceIn(50L, 2500L)) / 1000.0
        lastUpdateMs = nowMs

        // Prediction step
        val predCov = errorCov + processNoisePerSec * dtSec

        // Measurement update step
        val kalmanGain = predCov / (predCov + measurementNoise)
        estimate += kalmanGain * (z - estimate)
        errorCov = (1.0 - kalmanGain) * predCov
        return estimate
    }

    fun reset() {
        initialized = false
    }
}

data class PolarRadarSnapshot(
    val sectorDbm: List<Float?>,       // 36 bins (10 deg each, 0 = 0..10 deg North)
    val sectorCounts: List<Int>,
    val coverageFraction: Float,
    val estimatedBearingDeg: Float?,   // Compass azimuth pointing TOWARD the case
    val shadowContrastDb: Float        // Peak-to-null dipole contrast (aim for >= 5 dB)
)

class PolarBodyRadar {
    private val sumRssi = DoubleArray(36)
    private val counts = IntArray(36)

    fun recordSample(azimuthDeg: Float, rawRssi: Int) {
        val normalized = ((azimuthDeg % 360f) + 360f) % 360f
        val bin = (normalized / 10f).toInt().coerceIn(0, 35)
        sumRssi[bin] += rawRssi.toDouble()
        counts[bin] += 1
    }

    fun clear() {
        sumRssi.fill(0.0)
        counts.fill(0)
    }

    fun snapshot(): PolarRadarSnapshot {
        val rawAvg = arrayOfNulls<Double>(36)
        var populated = 0
        for (i in 0 until 36) {
            if (counts[i] > 0) {
                rawAvg[i] = sumRssi[i] / counts[i]
                populated++
            }
        }

        // Zero-phase symmetric circular smoothing [0.25, 0.50, 0.25] across neighbors
        val smoothed = MutableList<Float?>(36) { null }
        for (i in 0 until 36) {
            val prev = rawAvg[(i + 35) % 36]
            val curr = rawAvg[i]
            val next = rawAvg[(i + 1) % 36]
            if (curr == null && prev == null && next == null) continue

            var weightedSum = 0.0
            var weightTotal = 0.0
            if (prev != null) { weightedSum += 0.25 * prev; weightTotal += 0.25 }
            if (curr != null) { weightedSum += 0.50 * curr; weightTotal += 0.50 }
            if (next != null) { weightedSum += 0.25 * next; weightTotal += 0.25 }
            smoothed[i] = (weightedSum / weightTotal).toFloat()
        }

        val validValues = smoothed.filterNotNull()
        val coverage = populated / 36f
        if (validValues.size < 18) {
            return PolarRadarSnapshot(smoothed, counts.toList(), coverage, null, 0f)
        }

        // 1st-harmonic cardioid correlation: combines front line-of-sight peak (+cos)
        // and rear 180-deg human-torso attenuation shadow (-cos) simultaneously.
        val meanDbm = validValues.average()
        var sinSum = 0.0
        var cosSum = 0.0
        var activeBins = 0

        for (i in 0 until 36) {
            val v = smoothed[i] ?: continue
            val delta = v - meanDbm
            val centerRad = Math.toRadians(i * 10.0 + 5.0)
            sinSum += delta * sin(centerRad)
            cosSum += delta * cos(centerRad)
            activeBins++
        }

        val bearingDeg = ((Math.toDegrees(atan2(sinSum, cosSum)) + 360.0) % 360.0).toFloat()
        val contrastDb = (4.0 * hypot(sinSum, cosSum) / activeBins).toFloat()

        return PolarRadarSnapshot(
            sectorDbm = smoothed,
            sectorCounts = counts.toList(),
            coverageFraction = coverage,
            estimatedBearingDeg = bearingDeg,
            shadowContrastDb = contrastDb
        )
    }
}
