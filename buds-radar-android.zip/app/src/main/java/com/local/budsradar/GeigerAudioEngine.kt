package com.local.budsradar

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

class GeigerAudioEngine {
    @Volatile private var running = false
    @Volatile private var enabled = false
    @Volatile private var targetRssiDbm = -95.0
    @Volatile private var signalFresh = false
    private var worker: Thread? = null

    fun start() {
        if (running) return
        running = true
        worker = thread(name = "GeigerAudioThread", isDaemon = true) {
            runLoop()
        }
    }

    fun setEnabled(on: Boolean) {
        enabled = on
    }

    fun updateSignal(smoothedDbm: Double, isFresh: Boolean) {
        targetRssiDbm = smoothedDbm
        signalFresh = isFresh
    }

    fun stop() {
        running = false
        worker?.interrupt()
        worker = null
    }

    private fun runLoop() {
        val sampleRate = 44100
        val frameSamples = 882 // 20 ms chunks for responsive rate modulation
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(frameSamples * 4)

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val pcm = ShortArray(frameSamples)
        var samplesUntilNextClick = 0.0
        var clickSamplePos = Int.MAX_VALUE
        val clickDurationSamples = (sampleRate * 0.012).toInt() // 12 ms crisp chirp
        var currentPitchHz = 800.0

        track.play()
        try {
            while (running) {
                val active = enabled && signalFresh
                // Normalize [-95 dBm .. -45 dBm] -> [0.0 .. 1.0]
                val norm = ((targetRssiDbm - (-95.0)) / 50.0).coerceIn(0.0, 1.0)
                val clicksPerSec = 1.2 * 18.0.pow(norm)
                val intervalSamples = sampleRate / clicksPerSec

                for (i in 0 until frameSamples) {
                    if (!active) {
                        pcm[i] = 0
                        continue
                    }

                    if (samplesUntilNextClick <= 0.0) {
                        clickSamplePos = 0
                        currentPitchHz = 650.0 + 1400.0 * norm
                        samplesUntilNextClick += intervalSamples
                    }
                    samplesUntilNextClick -= 1.0

                    if (clickSamplePos < clickDurationSamples) {
                        val t = clickSamplePos.toDouble() / sampleRate
                        val envelope = exp(-t * 320.0) // Sharp Geiger attack + exponential decay
                        val wave = sin(2.0 * PI * currentPitchHz * t)
                        pcm[i] = (wave * envelope * 26000.0).toInt()
                            .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                        clickSamplePos++
                    } else {
                        pcm[i] = 0
                    }
                }
                track.write(pcm, 0, frameSamples, AudioTrack.WRITE_BLOCKING)
            }
        } catch (_: InterruptedException) {
            // Clean exit
        } finally {
            runCatching {
                track.stop()
                track.release()
            }
        }
    }
}
