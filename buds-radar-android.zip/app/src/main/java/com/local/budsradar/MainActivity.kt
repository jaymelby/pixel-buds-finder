package com.local.budsradar

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private val viewModel: BudsRadarViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LocalView.current.keepScreenOn = true
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0D1117)) {
                    BudsRadarScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun BudsRadarScreen(vm: BudsRadarViewModel) {
    val state by vm.uiState.collectAsState()
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.BLUETOOTH_SCAN] == true &&
            grants[Manifest.permission.ACCESS_FINE_LOCATION] == true
        ) {
            vm.startRadar()
        }
    }

    LaunchedEffect(Unit) {
        permLauncher.launch(
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Pixel Buds 0xFE2C Radar", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    if (state.isScanning) "LOW_LATENCY + AGGRESSIVE" else "Scanner Paused",
                    fontSize = 12.sp,
                    color = if (state.isScanning) Color(0xFF3FB950) else Color(0xFFF85149)
                )
            }
            Button(
                onClick = { if (state.isScanning) vm.stopRadar() else vm.startRadar() }
            ) {
                Text(if (state.isScanning) "Stop" else "Scan")
            }
        }

        state.scanError?.let { err ->
            Text(err, color = Color(0xFFF85149), fontSize = 13.sp)
        }
        state.handoffNotice?.let { msg ->
            Text(msg, color = Color(0xFF58A6FF), fontSize = 12.sp)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("KALMAN RSSI", fontSize = 11.sp, color = Color(0xFF8B949E))
                        val dbmText = state.smoothedRssi?.let { "%.1f dBm".format(it) } ?: "-- dBm"
                        val freshColor = if (state.signalAgeSec <= 3.5f) Color(0xFF58A6FF) else Color(0xFF6E7681)
                        Text(dbmText, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = freshColor)
                        Text(
                            "Raw: ${state.rawRssi ?: "--"} dBm  •  ${"%.1f".format(state.packetRateHz)} Hz  •  Age: ${"%.1f".format(state.signalAgeSec)}s",
                            fontSize = 12.sp,
                            color = Color(0xFF8B949E)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("GEIGER AUDIO", fontSize = 11.sp, color = Color(0xFF8B949E))
                        Switch(checked = state.geigerEnabled, onCheckedChange = vm::toggleGeiger)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Filter R (${state.measurementNoiseR.toInt()}):", fontSize = 12.sp, color = Color(0xFF8B949E))
                    Slider(
                        value = state.measurementNoiseR,
                        onValueChange = vm::setSmoothingNoiseR,
                        valueRange = 4f..30f,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("BODY-SHIELDING POLAR SWEEP", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        Text(
                            "Hold tight to sternum & rotate 360° (${(state.polar.coverageFraction * 100).toInt()}% bins)",
                            fontSize = 11.sp,
                            color = Color(0xFF8B949E)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = vm::clearPolarPlot, contentPadding = PaddingValues(horizontal = 10.dp)) {
                            Text("Reset", fontSize = 12.sp)
                        }
                        Button(
                            onClick = vm::toggleSpinCapture,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.isRecordingSpin) Color(0xFFDA3633) else Color(0xFF238636)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) {
                            Text(if (state.isRecordingSpin) "Stop Spin" else "Start Spin", fontSize = 12.sp)
                        }
                    }
                }

                if (state.isRecordingSpin && state.angularSpeedDegPerSec > 45f) {
                    Text(
                        "Spinning too fast (${state.angularSpeedDegPerSec.toInt()}°/s) — slow down so packets land cleanly",
                        color = Color(0xFFD29922),
                        fontSize = 12.sp
                    )
                }

                HeadsUpPolarCanvas(
                    headingDeg = state.headingDeg,
                    polar = state.polar,
                    modifier = Modifier.size(250.dp)
                )

                val bearingText = state.polar.estimatedBearingDeg?.let {
                    "Est. Case Bearing: ${it.toInt()}°  •  Torso Shadow Contrast: ${"%.1f".format(state.polar.shadowContrastDb)} dB"
                } ?: "Sweep at least 50% of the circle to solve bearing"
                Text(bearingText, fontSize = 12.sp, color = Color(0xFF3FB950), fontWeight = FontWeight.Medium)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("DETECTED 0xFE2C STREAMS (${state.candidates.size})", fontSize = 12.sp, color = Color(0xFF8B949E))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Include 0x00E0", fontSize = 11.sp, color = Color(0xFF8B949E))
                Checkbox(checked = state.broadGoogleFilter, onCheckedChange = vm::toggleBroadGoogleFilter)
            }
        }

        state.candidates.forEach { item ->
            val selected = item.mac == state.lockedMac
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) Color(0xFF1F2937) else Color(0xFF161B22)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.selectCandidate(item.mac) }
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "${item.mac} ${if (selected) "[LOCKED]" else ""}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (selected) Color(0xFF58A6FF) else Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("${item.lastRawRssi} dBm  (${item.packetCount} pkts)", fontSize = 12.sp, color = Color(0xFF8B949E))
                    }
                    if (item.batterySummary != null) {
                        Text("Battery: ${item.batterySummary}", fontSize = 12.sp, color = Color(0xFF3FB950))
                    }
                    Text(
                        "${item.rpaFingerprint}  •  ${item.payloadHex}",
                        fontSize = 11.sp,
                        color = Color(0xFF8B949E),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun HeadsUpPolarCanvas(
    headingDeg: Float,
    polar: PolarRadarSnapshot,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.background(Color(0xFF0D1117), RoundedCornerShape(125.dp))) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val maxR = size.minDimension * 0.44f

        listOf(0.33f, 0.66f, 1.0f).forEach { frac ->
            drawCircle(
                color = Color(0xFF30363D),
                radius = maxR * frac,
                center = Offset(cx, cy),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        drawLine(
            color = Color(0xFF58A6FF),
            start = Offset(cx, cy),
            end = Offset(cx, cy - maxR - 10.dp.toPx()),
            strokeWidth = 2.dp.toPx()
        )

        val northRelRad = Math.toRadians((-headingDeg - 90f).toDouble())
        val nx = cx + (maxR + 8.dp.toPx()) * cos(northRelRad).toFloat()
        val ny = cy + (maxR + 8.dp.toPx()) * sin(northRelRad).toFloat()
        drawCircle(color = Color(0xFFF85149), radius = 4.dp.toPx(), center = Offset(nx, ny))

        val valid = polar.sectorDbm.filterNotNull()
        val minDb = (valid.minOrNull() ?: -95f) - 3f
        val maxDb = (valid.maxOrNull() ?: -55f).coerceAtLeast(minDb + 8f)

        val lobePath = Path()
        var started = false
        for (bin in 0 until 36) {
            val dbm = polar.sectorDbm[bin] ?: continue
            val norm = ((dbm - minDb) / (maxDb - minDb)).coerceIn(0.12f, 1.0f)
            val r = maxR * norm
            val sectorAzimuth = bin * 10f + 5f
            val screenRad = Math.toRadians((sectorAzimuth - headingDeg - 90f).toDouble())
            val px = cx + r * cos(screenRad).toFloat()
            val py = cy + r * sin(screenRad).toFloat()

            drawCircle(color = Color(0xFF58A6FF), radius = 3.dp.toPx(), center = Offset(px, py))
            if (!started) {
                lobePath.moveTo(px, py)
                started = true
            } else {
                lobePath.lineTo(px, py)
            }
        }
        if (started) {
            drawPath(path = lobePath, color = Color(0x8858A6FF), style = Stroke(width = 2.dp.toPx()))
        }

        polar.estimatedBearingDeg?.let { bearing ->
            val brgRad = Math.toRadians((bearing - headingDeg - 90f).toDouble())
            val ex = cx + maxR * cos(brgRad).toFloat()
            val ey = cy + maxR * sin(brgRad).toFloat()
            drawLine(
                color = Color(0xFF3FB950),
                start = Offset(cx, cy),
                end = Offset(ex, ey),
                strokeWidth = 4.dp.toPx()
            )
            drawCircle(color = Color(0xFF3FB950), radius = 6.dp.toPx(), center = Offset(ex, ey))
        }
    }
}
