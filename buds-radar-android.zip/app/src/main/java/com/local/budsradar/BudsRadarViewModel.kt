package com.local.budsradar

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2

data class CandidateStream(
    val mac: String,
    val rpaFingerprint: String,
    val lastRawRssi: Int,
    val batterySummary: String?,
    val payloadHex: String,
    val packetCount: Int,
    val lastSeenElapsedMs: Long,
    val firstSeenElapsedMs: Long
)

data class RadarUiState(
    val isScanning: Boolean = false,
    val scanError: String? = null,
    val broadGoogleFilter: Boolean = false,
    val lockedMac: String? = null,
    val handoffNotice: String? = null,
    val rawRssi: Int? = null,
    val smoothedRssi: Float? = null,
    val packetRateHz: Float = 0f,
    val signalAgeSec: Float = 99f,
    val headingDeg: Float = 0f,
    val angularSpeedDegPerSec: Float = 0f,
    val isRecordingSpin: Boolean = false,
    val geigerEnabled: Boolean = false,
    val measurementNoiseR: Float = 14f,
    val candidates: List<CandidateStream> = emptyList(),
    val polar: PolarRadarSnapshot = PolarRadarSnapshot(
        List(36) { null }, List(36) { 0 }, 0f, null, 0f
    )
)

class BudsRadarViewModel(app: Application) : AndroidViewModel(app), SensorEventListener {
    private val btManager = app.getSystemService(BluetoothManager::class.java)
    private val sensorManager = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val kalman = RssiKalmanFilter()
    private val polarRadar = PolarBodyRadar()
    private val geiger = GeigerAudioEngine()

    private val streamMap = LinkedHashMap<String, CandidateStream>()
    private val recentPacketTimes = ArrayDeque<Long>()

    private val rotationMatrix = FloatArray(9)
    private var lastHeadingDeg = 0f
    private var lastSensorMs = 0L
    private var currentAngularVel = 0f

    private val _uiState = MutableStateFlow(RadarUiState())
    val uiState: StateFlow<RadarUiState> = _uiState.asStateFlow()

    init {
        geiger.start()
        viewModelScope.launch {
            while (true) {
                delay(250L)
                tickWatchdog()
            }
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            handleScanResult(result)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach(::handleScanResult)
        }

        override fun onScanFailed(errorCode: Int) {
            _uiState.update {
                it.copy(isScanning = false, scanError = "BLE Scan failed (code $errorCode). Toggle Bluetooth off/on.")
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startRadar() {
        val ctx = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            _uiState.update { it.copy(scanError = "Missing BLUETOOTH_SCAN permission.") }
            return
        }

        val scanner = btManager?.adapter?.bluetoothLeScanner
        if (scanner == null || btManager.adapter?.isEnabled != true) {
            _uiState.update { it.copy(scanError = "Bluetooth is turned off.") }
            return
        }

        stopRadar()

        val filters = if (_uiState.value.broadGoogleFilter) {
            emptyList() // Foreground software filter for 0xFE2C + Google 0x00E0
        } else {
            listOf(
                ScanFilter.Builder().setServiceData(FastPairParser.FE2C_UUID, ByteArray(0)).build(),
                ScanFilter.Builder().setServiceUuid(FastPairParser.FE2C_UUID).build()
            )
        }

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
            .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
            .setReportDelay(0L)
            .setLegacy(false)
            .build()

        scanner.startScan(filters, settings, scanCallback)

        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { rotSensor ->
            sensorManager.registerListener(this, rotSensor, SensorManager.SENSOR_DELAY_GAME)
        }

        _uiState.update { it.copy(isScanning = true, scanError = null) }
    }

    @SuppressLint("MissingPermission")
    fun stopRadar() {
        runCatching { btManager?.adapter?.bluetoothLeScanner?.stopScan(scanCallback) }
        sensorManager.unregisterListener(this)
        geiger.updateSignal(-100.0, false)
        _uiState.update { it.copy(isScanning = false) }
    }

    fun selectCandidate(mac: String) {
        kalman.reset()
        polarRadar.clear()
        recentPacketTimes.clear()
        _uiState.update {
            it.copy(
                lockedMac = mac,
                handoffNotice = null,
                rawRssi = null,
                smoothedRssi = null,
                polar = polarRadar.snapshot()
            )
        }
    }

    fun toggleSpinCapture() {
        _uiState.update { state ->
            val next = !state.isRecordingSpin
            if (next) polarRadar.clear()
            state.copy(isRecordingSpin = next, polar = polarRadar.snapshot())
        }
    }

    fun clearPolarPlot() {
        polarRadar.clear()
        _uiState.update { it.copy(polar = polarRadar.snapshot()) }
    }

    fun toggleGeiger(enabled: Boolean) {
        geiger.setEnabled(enabled)
        _uiState.update { it.copy(geigerEnabled = enabled) }
    }

    fun setSmoothingNoiseR(rValue: Float) {
        kalman.measurementNoise = rValue.toDouble()
        _uiState.update { it.copy(measurementNoiseR = rValue) }
    }

    fun toggleBroadGoogleFilter(broad: Boolean) {
        _uiState.update { it.copy(broadGoogleFilter = broad) }
        if (_uiState.value.isScanning) startRadar()
    }

    private fun handleScanResult(result: ScanResult) {
        val record = result.scanRecord ?: return
        val fe2cBytes = record.getServiceData(FastPairParser.FE2C_UUID)
        val hasFe2cUuid = record.serviceUuids?.contains(FastPairParser.FE2C_UUID) == true
        val googleMfgBytes = record.getManufacturerSpecificData(FastPairParser.GOOGLE_MANUFACTURER_ID)

        if (fe2cBytes == null && !hasFe2cUuid && (!_uiState.value.broadGoogleFilter || googleMfgBytes == null)) {
            return
        }

        val nowMs = SystemClock.elapsedRealtime()
        val parsed = fe2cBytes?.let { FastPairParser.parse(it) }
        val mac = result.device.address
        val prev = streamMap[mac]

        // Preserve last decoded battery status across non-battery Fast Pair frames
        val batteryText = parsed?.battery?.formatSummary() ?: prev?.batterySummary
        val fingerprint = parsed?.rpaFingerprint
            ?: if (googleMfgBytes != null) "GOOGLE_MFG_${googleMfgBytes.size}" else "FE2C_UUID"

        val updatedStream = CandidateStream(
            mac = mac,
            rpaFingerprint = fingerprint,
            lastRawRssi = result.rssi,
            batterySummary = batteryText,
            payloadHex = parsed?.rawHex ?: googleMfgBytes?.joinToString(":") { "%02X".format(it) } ?: "--",
            packetCount = (prev?.packetCount ?: 0) + 1,
            lastSeenElapsedMs = nowMs,
            firstSeenElapsedMs = prev?.firstSeenElapsedMs ?: nowMs
        )
        streamMap[mac] = updatedStream

        val state = _uiState.value
        var activeMac = state.lockedMac
        var handoffMsg = state.handoffNotice

        // Auto-lock onto first Fast Pair Account Data stream if nothing is selected yet
        if (activeMac == null && (parsed?.isAccountData == true || fe2cBytes != null)) {
            activeMac = mac
        }

        // Seamless RPA MAC rotation handoff
        if (activeMac != null && activeMac != mac) {
            val lockedStream = streamMap[activeMac]
            if (lockedStream != null &&
                nowMs - lockedStream.lastSeenElapsedMs > 4000L &&
                nowMs - updatedStream.firstSeenElapsedMs < 6000L &&
                lockedStream.rpaFingerprint == updatedStream.rpaFingerprint
            ) {
                activeMac = mac
                handoffMsg = "RPA MAC rotated -> seamlessly followed to $mac"
            }
        }

        if (mac == activeMac) {
            val smoothed = kalman.update(result.rssi, nowMs)
            recentPacketTimes.addLast(nowMs)
            while (recentPacketTimes.isNotEmpty() && nowMs - recentPacketTimes.first() > 3000L) {
                recentPacketTimes.removeFirst()
            }
            val hz = recentPacketTimes.size / 3f

            // Only bin into polar sectors when spinning slowly (< 45 deg/s) to avoid motion smear
            if (state.isRecordingSpin && currentAngularVel < 45f) {
                polarRadar.recordSample(lastHeadingDeg, result.rssi)
            }

            geiger.updateSignal(smoothed, true)

            _uiState.update {
                it.copy(
                    lockedMac = activeMac,
                    handoffNotice = handoffMsg,
                    rawRssi = result.rssi,
                    smoothedRssi = smoothed.toFloat(),
                    packetRateHz = hz,
                    signalAgeSec = 0f,
                    polar = if (state.isRecordingSpin) polarRadar.snapshot() else it.polar
                )
            }
        } else if (activeMac != state.lockedMac) {
            _uiState.update { it.copy(lockedMac = activeMac) }
        }
    }

    private fun tickWatchdog() {
        val nowMs = SystemClock.elapsedRealtime()
        val locked = _uiState.value.lockedMac
        streamMap.entries.removeIf { (k, v) -> k != locked && nowMs - v.lastSeenElapsedMs > 45_000L }

        val lockedStream = locked?.let { streamMap[it] }
        val ageSec = if (lockedStream != null) (nowMs - lockedStream.lastSeenElapsedMs) / 1000f else 99f
        val fresh = ageSec <= 3.5f
        if (!fresh) {
            geiger.updateSignal(-100.0, false)
        }

        val sortedCandidates = streamMap.values.sortedByDescending { it.lastRawRssi }
        _uiState.update {
            it.copy(
                signalAgeSec = ageSec,
                candidates = sortedCandidates
            )
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val vec = if (event.values.size > 4) event.values.sliceArray(0..3) else event.values
        SensorManager.getRotationMatrixFromVector(rotationMatrix, vec)

        // Project Device(+Y) + Device(-Z) onto World (East, North) for gimbal-lock-free chest tilt
        val east = rotationMatrix[1] - rotationMatrix[2]
        val north = rotationMatrix[4] - rotationMatrix[5]
        val azimuthDeg = ((Math.toDegrees(atan2(east.toDouble(), north.toDouble())) + 360.0) % 360.0).toFloat()

        val nowMs = SystemClock.elapsedRealtime()
        if (lastSensorMs != 0L) {
            val dt = ((nowMs - lastSensorMs).coerceAtLeast(1L)) / 1000f
            var delta = abs(azimuthDeg - lastHeadingDeg)
            if (delta > 180f) delta = 360f - delta
            currentAngularVel = 0.7f * currentAngularVel + 0.3f * (delta / dt)
        }
        lastHeadingDeg = azimuthDeg
        lastSensorMs = nowMs

        _uiState.update {
            it.copy(headingDeg = azimuthDeg, angularSpeedDegPerSec = currentAngularVel)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onCleared() {
        stopRadar()
        geiger.stop()
        super.onCleared()
    }
}
