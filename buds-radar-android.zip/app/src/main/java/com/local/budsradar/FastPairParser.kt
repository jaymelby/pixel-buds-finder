package com.local.budsradar

import android.os.ParcelUuid

object FastPairParser {
    val FE2C_UUID: ParcelUuid = ParcelUuid.fromString("0000FE2C-0000-1000-8000-00805F9B34FB")
    const val GOOGLE_MANUFACTURER_ID = 0x00E0

    data class BatteryTuple(
        val leftPct: Int?,
        val leftCharging: Boolean,
        val rightPct: Int?,
        val rightCharging: Boolean,
        val casePct: Int?,
        val caseCharging: Boolean
    ) {
        fun formatSummary(): String {
            fun fmt(label: String, pct: Int?, chg: Boolean): String {
                val v = pct?.let { "$it%" } ?: "--"
                return "$label:$v${if (chg) "+" else ""}"
            }
            return "${fmt("L", leftPct, leftCharging)}  ${fmt("R", rightPct, rightCharging)}  ${fmt("Case", casePct, caseCharging)}"
        }
    }

    data class ParsedFrame(
        val isAccountData: Boolean,
        val modelIdHex: String?,
        val accountFilterLen: Int?,
        val battery: BatteryTuple?,
        val rawHex: String,
        val rpaFingerprint: String
    )

    fun parse(payload: ByteArray): ParsedFrame {
        val rawHex = payload.joinToString(":") { "%02X".format(it) }
        if (payload.isEmpty()) {
            return ParsedFrame(false, null, null, null, rawHex, "EMPTY")
        }

        val byte0 = payload[0].toInt() and 0xFF
        // Discoverable mode: 3-byte 24-bit Fast Pair Model ID (version bits non-zero)
        if (payload.size == 3 && (byte0 and 0xE0) != 0) {
            val modelId = "%02X%02X%02X".format(payload[0], payload[1], payload[2])
            return ParsedFrame(false, modelId, null, null, rawHex, "MODEL_$modelId")
        }

        // Non-discoverable mode: Byte 0 top 3 bits == 0b000, followed by packed LTV fields
        val version = (byte0 ushr 5) and 0x07
        var idx = 1
        var filterLen: Int? = null
        var battery: BatteryTuple? = null

        while (idx < payload.size) {
            val header = payload[idx].toInt() and 0xFF
            val len = (header ushr 4) and 0x0F
            val type = header and 0x0F
            if (idx + 1 + len > payload.size) break

            when (type) {
                0x0, 0x2 -> { // Account Key Filter (0x0 = show UI, 0x2 = hide UI)
                    filterLen = len
                }
                0x3, 0x4 -> { // Battery Notification (0x3 = show UI, 0x4 = hide UI)
                    if (len >= 3) {
                        val (lPct, lChg) = decodeBatteryByte(payload[idx + 1])
                        val (rPct, rChg) = decodeBatteryByte(payload[idx + 2])
                        val (cPct, cChg) = decodeBatteryByte(payload[idx + 3])
                        if (lPct != null || rPct != null || cPct != null) {
                            battery = BatteryTuple(lPct, lChg, rPct, rChg, cPct, cChg)
                        }
                    }
                }
            }
            idx += 1 + len
        }

        val fingerprint = "FP_v${version}_akLen${filterLen ?: -1}"
        return ParsedFrame(
            isAccountData = filterLen != null,
            modelIdHex = null,
            accountFilterLen = filterLen,
            battery = battery,
            rawHex = rawHex,
            rpaFingerprint = fingerprint
        )
    }

    private fun decodeBatteryByte(b: Byte): Pair<Int?, Boolean> {
        val raw = b.toInt() and 0xFF
        val charging = (raw and 0x80) != 0
        val level = raw and 0x7F
        // 0x7F (127) indicates unknown/offline in the Fast Pair spec
        return (if (level in 0..100) level else null) to charging
    }
}
